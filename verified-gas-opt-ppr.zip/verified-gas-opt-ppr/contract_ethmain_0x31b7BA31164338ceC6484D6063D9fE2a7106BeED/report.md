**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (4 results) (Optimization)
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[ForPNut.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L327-L337) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L329)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L333)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L327-L337


 - [ ] ID-1
[ForPNut.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L264-L276) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L266)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L268)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L269-L275)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L264-L276


 - [ ] ID-2
[ForPNut.openTrading()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L304-L315) casts address(this) 5 time(s):-
	- [_approve(address(this),msg.sender,type()(uint256).max)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L307)
	- [transfer(address(this),balanceOf(msg.sender).mul(95).div(100))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L308)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L309)
	- [_approve(address(this),address(uniswapV2Router),type()(uint256).max)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L310)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L311)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L304-L315


 - [ ] ID-3
[ForPNut._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L213-L257) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L228)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L233)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L240)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L242)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L250)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L251)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L213-L257


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-4
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L39-L46) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L44)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L39-L46


 - [ ] ID-5
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L52-L56) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L54)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L52-L56


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-6
[ForPNut](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L115-L339) should use bytes32 for following string constant(s) :-
	- [ForPNut._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L134)
	- [ForPNut._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L135)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x31b7BA31164338ceC6484D6063D9fE2a7106BeED/contract.sol#L115-L339


