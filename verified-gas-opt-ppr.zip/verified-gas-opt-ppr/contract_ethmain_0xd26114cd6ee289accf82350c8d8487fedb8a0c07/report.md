**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd26114cd6ee289accf82350c8d8487fedb8a0c07/contract.sol#L14-L19) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd26114cd6ee289accf82350c8d8487fedb8a0c07/contract.sol#L16)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd26114cd6ee289accf82350c8d8487fedb8a0c07/contract.sol#L14-L19


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd26114cd6ee289accf82350c8d8487fedb8a0c07/contract.sol#L8-L12) perform division which can not overflow (can use unchecked) :-
	- [assert(a == 0 || c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd26114cd6ee289accf82350c8d8487fedb8a0c07/contract.sol#L10)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd26114cd6ee289accf82350c8d8487fedb8a0c07/contract.sol#L8-L12


