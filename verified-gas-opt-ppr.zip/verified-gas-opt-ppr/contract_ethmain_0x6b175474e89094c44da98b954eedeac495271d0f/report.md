**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Dai](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x6b175474e89094c44da98b954eedeac495271d0f/contract.sol#L69-L191) should use bytes32 for following string constant(s) :-
	- [Dai.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x6b175474e89094c44da98b954eedeac495271d0f/contract.sol#L80)
	- [Dai.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x6b175474e89094c44da98b954eedeac495271d0f/contract.sol#L81)
	- [Dai.version](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x6b175474e89094c44da98b954eedeac495271d0f/contract.sol#L82)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x6b175474e89094c44da98b954eedeac495271d0f/contract.sol#L69-L191


