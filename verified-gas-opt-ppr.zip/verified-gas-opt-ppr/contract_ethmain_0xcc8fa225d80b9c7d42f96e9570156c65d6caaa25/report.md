**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcc8fa225d80b9c7d42f96e9570156c65d6caaa25/contract.sol#L26-L31) perform division which can not overflow (can use unchecked) :-
	- [a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcc8fa225d80b9c7d42f96e9570156c65d6caaa25/contract.sol#L30)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcc8fa225d80b9c7d42f96e9570156c65d6caaa25/contract.sol#L26-L31


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcc8fa225d80b9c7d42f96e9570156c65d6caaa25/contract.sol#L17-L24) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcc8fa225d80b9c7d42f96e9570156c65d6caaa25/contract.sol#L23)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcc8fa225d80b9c7d42f96e9570156c65d6caaa25/contract.sol#L17-L24


