**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9e9801bace260f58407c15e6e515c45918756e0f/contract.sol#L13-L24) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9e9801bace260f58407c15e6e515c45918756e0f/contract.sol#L22)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9e9801bace260f58407c15e6e515c45918756e0f/contract.sol#L13-L24


 - [ ] ID-1
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9e9801bace260f58407c15e6e515c45918756e0f/contract.sol#L29-L34) perform division which can not overflow (can use unchecked) :-
	- [a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9e9801bace260f58407c15e6e515c45918756e0f/contract.sol#L33)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9e9801bace260f58407c15e6e515c45918756e0f/contract.sol#L29-L34


