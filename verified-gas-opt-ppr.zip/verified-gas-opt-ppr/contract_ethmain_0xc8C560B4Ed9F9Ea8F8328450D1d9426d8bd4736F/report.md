**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (5 results) (Optimization)
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Contract.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L160-L168) casts address(this) 3 time(s):-
	- [_balances[address(this)] = _tTotal](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L162)
	- [_isExcludedFromFee[address(this)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L164)
	- [Transfer(address(this),_msgSender(),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L167)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L160-L168


 - [ ] ID-1
[Contract.openTrading()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L316-L325) casts address(this) 3 time(s):-
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L319)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L320)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L321)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L316-L325


 - [ ] ID-2
[Contract._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L217-L266) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L239)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L243)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L250)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L252)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L260)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L261)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L217-L266


 - [ ] ID-3
[Contract.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L273-L285) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L275)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L277)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L278-L284)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L273-L285


 - [ ] ID-4
[Contract.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L337-L347) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L339)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L343)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L337-L347


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-5
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L57-L61) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L59)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L57-L61


 - [ ] ID-6
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L44-L51) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L49)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L44-L51


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-7
[Contract](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L115-L357) should use bytes32 for following string constant(s) :-
	- [Contract._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L117)
	- [Contract._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L118)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc8C560B4Ed9F9Ea8F8328450D1d9426d8bd4736F/contract.sol#L115-L357


