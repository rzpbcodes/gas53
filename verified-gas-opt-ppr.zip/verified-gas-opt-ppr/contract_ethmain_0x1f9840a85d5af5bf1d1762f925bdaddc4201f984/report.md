**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (4 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L112-L124) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,errorMessage)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L121)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L112-L124


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L90-L102) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L99)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L90-L102


 - [ ] ID-2
[Uni.getPriorVotes(address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L470-L502) perform division which can not overflow (can use unchecked) :-
	- [center = upper - (upper - lower) / 2](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L491)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L470-L502


 - [ ] ID-3
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L152-L159) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L155)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L152-L159


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-4
[Uni](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L193-L583) should use bytes32 for following string constant(s) :-
	- [Uni.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L195)
	- [Uni.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L198)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1f9840a85d5af5bf1d1762f925bdaddc4201f984/contract.sol#L193-L583


