**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (4 results) (Optimization)
 - [div-by-uint](#div-by-uint) (4 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[PRESIDENTELECTTRUMP.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L392-L402) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L395)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L400)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L392-L402


 - [ ] ID-1
[PRESIDENTELECTTRUMP.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L290-L302) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L292)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L294)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L295-L301)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L290-L302


 - [ ] ID-2
[PRESIDENTELECTTRUMP._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L223-L283) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L253)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L257)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L265)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L267)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L276)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L277)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L223-L283


 - [ ] ID-3
[PRESIDENTELECTTRUMP.addLP()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L329-L336) casts address(this) 3 time(s):-
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L332)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L333)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L334)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L329-L336


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-4
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L46-L53) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L51)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L46-L53


 - [ ] ID-5
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L59-L63) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L61)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L59-L63


 - [ ] ID-6
[PRESIDENTELECTTRUMP.slitherConstructorVariables()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L117-L403) perform division which can not overflow (can use unchecked) :-
	- [_maxTxAmount = (_tTotal * 20) / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L140)
	- [_maxWalletSize = (_tTotal * 20) / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L141)
	- [_taxSwapThreshold = (_tTotal * 1) / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L142)
	- [_maxTaxSwap = (_tTotal * 500) / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L143)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L117-L403


 - [ ] ID-7
[PRESIDENTELECTTRUMP.sendETHToFee(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L315-L327) perform division which can not overflow (can use unchecked) :-
	- [ethForDev = amount * _devPortion / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L320)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L315-L327


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-8
[PRESIDENTELECTTRUMP](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L117-L403) should use bytes32 for following string constant(s) :-
	- [PRESIDENTELECTTRUMP._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L138)
	- [PRESIDENTELECTTRUMP._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L139)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa3A31df07358dE259291493A29F843cD999AaB46/contract.sol#L117-L403


