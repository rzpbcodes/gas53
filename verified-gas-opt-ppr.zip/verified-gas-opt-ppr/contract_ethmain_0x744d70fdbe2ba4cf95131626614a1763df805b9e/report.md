**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (3 results) (Optimization)
 - [unnec-casting-same-type](#unnec-casting-same-type) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L99-L104) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L101)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L99-L104


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L93-L97) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(a == 0 || c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L95)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L93-L97


 - [ ] ID-2
[MiniMeToken.getValueAt(MiniMeToken.Checkpoint[],uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L771-L792) perform division which can not overflow (can use unchecked) :-
	- [mid = (max + min + 1) / 2](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L784)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L771-L792


## unnec-casting-same-type
Impact: Optimization
Confidence: High
 - [ ] ID-3
[StatusContribution.initialize(address,address,uint256,uint256,address,address,address,address,address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L1051-L1105) performs same type cast
	- [require(bool)(_maxSGTSupply >= MiniMeToken(SGT).totalSupply())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L1103) casts (MiniMeToken) to (MiniMeToken).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x744d70fdbe2ba4cf95131626614a1763df805b9e/contract.sol#L1051-L1105


