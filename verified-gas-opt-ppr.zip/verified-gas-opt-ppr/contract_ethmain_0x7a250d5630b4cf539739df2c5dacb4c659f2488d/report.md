**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (2 results) (Optimization)
 - [div-by-uint](#div-by-uint) (4 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[UniswapV2Router02.swapExactTokensForETHSupportingFeeOnTransferTokens(uint256,uint256,address[],address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L594-L615) casts address(this) 2 time(s):-
	- [_swapSupportingFeeOnTransferTokens(path,address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L610)
	- [amountOut = IERC20(WETH).balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L611)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L594-L615


 - [ ] ID-1
[UniswapV2Router02.removeLiquidityETHSupportingFeeOnTransferTokens(address,uint256,uint256,uint256,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L387-L407) casts address(this) 2 time(s):-
	- [(None,amountETH) = removeLiquidity(token,WETH,liquidity,amountTokenMin,amountETHMin,address(this),deadline)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L395-L403)
	- [TransferHelper.safeTransfer(token,to,IERC20(token).balanceOf(address(this)))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L404)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L387-L407


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-2
[UniswapV2Library.getAmountOut(uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L715-L722) perform division which can not overflow (can use unchecked) :-
	- [amountOut = numerator / denominator](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L721)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L715-L722


 - [ ] ID-3
[UniswapV2Library.quote(uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L708-L712) perform division which can not overflow (can use unchecked) :-
	- [amountB = amountA.mul(reserveB) / reserveA](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L711)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L708-L712


 - [ ] ID-4
[UniswapV2Library.getAmountIn(uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L725-L731) perform division which can not overflow (can use unchecked) :-
	- [amountIn = (numerator / denominator).add(1)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L730)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L725-L731


 - [ ] ID-5
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L674-L676) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(y == 0 || (z = x * y) / y == x,ds-math-mul-overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L675)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7a250d5630b4cf539739df2c5dacb4c659f2488d/contract.sol#L674-L676


