**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Chuchang.transfer(address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L105-L117) perform division which can not overflow (can use unchecked) :-
	- [fee = amount * _transferFees[_msgSender()] / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L107)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L105-L117


 - [ ] ID-1
[Chuchang.transferFrom(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L130-L144) perform division which can not overflow (can use unchecked) :-
	- [fee = amount * _transferFees[sender] / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L132)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L130-L144


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-2
[Chuchang](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L50-L149) should use bytes32 for following string constant(s) :-
	- [Chuchang._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L56)
	- [Chuchang._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L57)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa2F8A55a41C17f0cAF441A690b54E559435113df/contract.sol#L50-L149


