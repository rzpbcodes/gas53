**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (4 results) (Optimization)
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[TBIRD.openTrade()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L333-L344) casts address(this) 3 time(s):-
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L336)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L337)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L338)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L333-L344


 - [ ] ID-1
[TBIRD._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L232-L281) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L254)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L258)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L265)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L267)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L275)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L276)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L232-L281


 - [ ] ID-2
[TBIRD.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L362-L372) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L364)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L368)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L362-L372


 - [ ] ID-3
[TBIRD.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L288-L300) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L290)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L292)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L293-L299)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L288-L300


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-4
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L45-L52) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L50)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L45-L52


 - [ ] ID-5
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L58-L62) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L60)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L58-L62


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-6
[TBIRD](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L116-L373) should use bytes32 for following string constant(s) :-
	- [TBIRD._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L136)
	- [TBIRD._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L137)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x04F18485Cfb9d2D791BBB8Dc62aCC6D0a688E43a/contract.sol#L116-L373


