**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (4 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[GNTAllocation.unlock()]() perform division which can not overflow (can use unchecked) :-
	- [toTransfer = tokensCreated * allocation / totalAllocations]()

 - [ ] ID-1
[GolemNetworkToken.refund()]() perform division which can not overflow (can use unchecked) :-
	- [ethValue = gntValue / tokenCreationRate]()

 - [ ] ID-2
[GolemNetworkToken.create()]() perform division which can not overflow (can use unchecked) :-
	- [msg.value > (tokenCreationCap - totalTokens) / tokenCreationRate]()

 - [ ] ID-3
[GolemNetworkToken.finalize()]() perform division which can not overflow (can use unchecked) :-
	- [additionalTokens = totalTokens * percentOfTotal / (100 - percentOfTotal)]()

