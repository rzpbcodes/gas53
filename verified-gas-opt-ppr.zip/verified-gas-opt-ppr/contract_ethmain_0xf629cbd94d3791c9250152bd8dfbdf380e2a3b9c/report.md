**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Utils.safeMul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xf629cbd94d3791c9250152bd8dfbdf380e2a3b9c/contract.sol#L61-L65) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(_x == 0 || z / _x == _y)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xf629cbd94d3791c9250152bd8dfbdf380e2a3b9c/contract.sol#L63)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xf629cbd94d3791c9250152bd8dfbdf380e2a3b9c/contract.sol#L61-L65


 - [ ] ID-1
[ENJToken.releaseEnjinTeamTokens()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xf629cbd94d3791c9250152bd8dfbdf380e2a3b9c/contract.sol#L409-L426) perform division which can not overflow (can use unchecked) :-
	- [enjinTeamAlloc = enjinTeamAllocation / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xf629cbd94d3791c9250152bd8dfbdf380e2a3b9c/contract.sol#L412)
	- [currentTranche = uint256(now - endTime) / 7257600](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xf629cbd94d3791c9250152bd8dfbdf380e2a3b9c/contract.sol#L413)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xf629cbd94d3791c9250152bd8dfbdf380e2a3b9c/contract.sol#L409-L426


