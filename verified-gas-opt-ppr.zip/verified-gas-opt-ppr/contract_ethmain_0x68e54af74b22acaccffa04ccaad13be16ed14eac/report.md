**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x68e54af74b22acaccffa04ccaad13be16ed14eac/contract.sol#L287-L299) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x68e54af74b22acaccffa04ccaad13be16ed14eac/contract.sol#L296)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x68e54af74b22acaccffa04ccaad13be16ed14eac/contract.sol#L287-L299


 - [ ] ID-1
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x68e54af74b22acaccffa04ccaad13be16ed14eac/contract.sol#L312-L319) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x68e54af74b22acaccffa04ccaad13be16ed14eac/contract.sol#L315)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x68e54af74b22acaccffa04ccaad13be16ed14eac/contract.sol#L312-L319


