**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (4 results) (Optimization)
 - [div-by-uint](#div-by-uint) (8 results) (Optimization)
 - [unnec-casting-same-type](#unnec-casting-same-type) (3 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Capybara.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1351-L1367) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1354)
	- [_approve(address(this),address(dexRouter),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1357)
	- [dexRouter.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1360-L1366)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1351-L1367


 - [ ] ID-1
[Capybara.swapBack(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1369-L1392) casts address(this) 2 time(s):-
	- [contractBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1370)
	- [(success,None) = address(marketingWallet).call{value: address(this).balance}()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1389-L1391)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1369-L1392


 - [ ] ID-2
[Capybara.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L927-L978) casts address(this) 3 time(s):-
	- [dexPair = IDexFactory(_dexRouter.factory()).createPair(address(this),_dexRouter.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L935-L938)
	- [taxesExemptSet(address(this),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L962)
	- [txLimitSetExempt(address(this),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L967)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L927-L978


 - [ ] ID-3
[Capybara._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1234-L1349) casts address(this) 2 time(s):-
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1292)
	- [super._transfer(from,address(this),fees)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1342)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1234-L1349


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-4
[Capybara.trxLimitsChangeWalletMax(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1049-L1055) perform division which can not overflow (can use unchecked) :-
	- [maxWallet = (_maxWallet * totalSupply()) / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1053)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1049-L1055


 - [ ] ID-5
[SafeMath.tryMul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L47-L60) perform division which can not overflow (can use unchecked) :-
	- [c / a != b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L57)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L47-L60


 - [ ] ID-6
[Capybara.txLimitsSetTxMax(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1037-L1041) perform division which can not overflow (can use unchecked) :-
	- [maxTx = (_maxTx * totalSupply()) / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1039)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1037-L1041


 - [ ] ID-7
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L200-L209) perform division which can not overflow (can use unchecked) :-
	- [a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L207)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L200-L209


 - [ ] ID-8
[SafeMath.tryDiv(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L67-L75) perform division which can not overflow (can use unchecked) :-
	- [(true,a / b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L73)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L67-L75


 - [ ] ID-9
[Capybara.setValuesSwapback(bool,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1011-L1029) perform division which can not overflow (can use unchecked) :-
	- [swapBackValueMin = (totalSupply() * _caSBcTrigger) / 10000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1026)
	- [swapBackValueMax = (totalSupply() * _caSBcLimit) / 10000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1027)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1011-L1029


 - [ ] ID-10
[Capybara.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L927-L978) perform division which can not overflow (can use unchecked) :-
	- [maxTx = (_totalSupply * 10) / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L946)
	- [maxWallet = (_totalSupply * 10) / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L947)
	- [swapBackValueMin = (_totalSupply * 1) / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L949)
	- [swapBackValueMax = (_totalSupply * 2) / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L950)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L927-L978


 - [ ] ID-11
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L144-L146) perform division which can not overflow (can use unchecked) :-
	- [a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L145)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L144-L146


## unnec-casting-same-type
Impact: Optimization
Confidence: High
 - [ ] ID-12
[Capybara.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L927-L978) performs same type cast
	- [txLimitSetExempt(address(dexPair),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L939) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L927-L978


 - [ ] ID-13
[Capybara.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L927-L978) performs same type cast
	- [txLimitSetExempt(address(dexPair),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L939) casts (address) to (address).
	- [_setPairLPool(address(dexPair),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L940) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L927-L978


 - [ ] ID-14
[Capybara.swapBack(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1369-L1392) performs same type cast
	- [(success,None) = address(marketingWallet).call{value: address(this).balance}()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1389-L1391) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcaBA229b971f870b28D21686163a543Af342B439/contract.sol#L1369-L1392


