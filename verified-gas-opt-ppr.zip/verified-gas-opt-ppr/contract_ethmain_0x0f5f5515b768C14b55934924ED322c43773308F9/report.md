**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (2 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Address.functionCallWithValue(address,bytes,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5f5515b768C14b55934924ED322c43773308F9/contract.sol#L211-L217) casts address(this) 2 time(s):-
	- [address(this).balance < value](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5f5515b768C14b55934924ED322c43773308F9/contract.sol#L212)
	- [revert AddressInsufficientBalance(address)(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5f5515b768C14b55934924ED322c43773308F9/contract.sol#L213)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5f5515b768C14b55934924ED322c43773308F9/contract.sol#L211-L217


 - [ ] ID-1
[Address.sendValue(address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5f5515b768C14b55934924ED322c43773308F9/contract.sol#L169-L178) casts address(this) 2 time(s):-
	- [address(this).balance < amount](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5f5515b768C14b55934924ED322c43773308F9/contract.sol#L170)
	- [revert AddressInsufficientBalance(address)(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5f5515b768C14b55934924ED322c43773308F9/contract.sol#L171)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5f5515b768C14b55934924ED322c43773308F9/contract.sol#L169-L178


