**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (3 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Exchange.adminWithdraw(address,uint256,address,uint256,uint8,bytes32,bytes32,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L122-L139) perform division which can not overflow (can use unchecked) :-
	- [tokens[token][feeAccount] = safeAdd(tokens[token][feeAccount],safeMul(feeWithdrawal,amount) / 1000000000000000000)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L130)
	- [amount = safeMul((1000000000000000000 - feeWithdrawal),amount) / 1000000000000000000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L131)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L122-L139


 - [ ] ID-1
[Exchange.safeMul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L22-L26) perform division which can not overflow (can use unchecked) :-
	- [assert(a == 0 || c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L24)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L22-L26


 - [ ] ID-2
[Exchange.trade(uint256[8],address[4],uint8[2],bytes32[4])](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L145-L183) perform division which can not overflow (can use unchecked) :-
	- [tokens[tradeAddresses[1]][tradeAddresses[2]] < (safeMul(tradeValues[1],tradeValues[4]) / tradeValues[0])](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L173)
	- [tokens[tradeAddresses[0]][tradeAddresses[2]] = safeAdd(tokens[tradeAddresses[0]][tradeAddresses[2]],safeMul(tradeValues[4],((1000000000000000000) - tradeValues[6])) / (1000000000000000000))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L175)
	- [tokens[tradeAddresses[0]][feeAccount] = safeAdd(tokens[tradeAddresses[0]][feeAccount],safeMul(tradeValues[4],tradeValues[6]) / (1000000000000000000))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L176)
	- [tokens[tradeAddresses[1]][tradeAddresses[2]] = safeSub(tokens[tradeAddresses[1]][tradeAddresses[2]],safeMul(tradeValues[1],tradeValues[4]) / tradeValues[0])](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L177)
	- [tokens[tradeAddresses[1]][tradeAddresses[3]] = safeAdd(tokens[tradeAddresses[1]][tradeAddresses[3]],safeMul(safeMul(((1000000000000000000) - tradeValues[7]),tradeValues[1]),tradeValues[4]) / tradeValues[0] / (1000000000000000000))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L178)
	- [tokens[tradeAddresses[1]][feeAccount] = safeAdd(tokens[tradeAddresses[1]][feeAccount],safeMul(safeMul(tradeValues[7],tradeValues[1]),tradeValues[4]) / tradeValues[0] / (1000000000000000000))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L179)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2a0c0dbecc7e4d658f48e01e3fa353f44050c208/contract.sol#L145-L183


