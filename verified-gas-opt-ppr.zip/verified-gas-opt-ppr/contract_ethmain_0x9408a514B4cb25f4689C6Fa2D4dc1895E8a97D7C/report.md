**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (3 results) (Optimization)
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
 - [unnec-casting-same-type](#unnec-casting-same-type) (4 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[POTUS.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L304-L316) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L306)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L308)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L309-L315)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L304-L316


 - [ ] ID-1
[POTUS.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L170-L185) casts address(this) 5 time(s):-
	- [_balances[address(this)] = _tTotal](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L173)
	- [isExile[address(this)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L175)
	- [Transfer(address(0),address(this),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L178)
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L181)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L182)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L170-L185


 - [ ] ID-2
[POTUS._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L234-L297) casts address(this) 9 time(s):-
	- [marketPair[to] && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L258)
	- [! marketPair[from] && ! marketPair[to] && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L262)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L266)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L273)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L275)
	- [contractETHBalance_scope_0 = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L283)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L285)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L291)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L292)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L234-L297


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-3
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L60-L64) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L62)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L60-L64


 - [ ] ID-4
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L47-L54) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L52)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L47-L54


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-5
[POTUS](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L123-L349) should use bytes32 for following string constant(s) :-
	- [POTUS._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L148)
	- [POTUS._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L149)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L123-L349


## unnec-casting-same-type
Impact: Optimization
Confidence: High
 - [ ] ID-6
[POTUS.rescueETH()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L322-L325) performs same type cast
	- [address(_taxWallet).transfer(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L324) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L322-L325


 - [ ] ID-7
[POTUS.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L170-L185) performs same type cast
	- [isExile[address(uniswapV2Pair)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L176) casts (address) to (address).
	- [marketPair[address(uniswapV2Pair)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L183) casts (address) to (address).
	- [isExile[address(uniswapV2Pair)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L184) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L170-L185


 - [ ] ID-8
[POTUS.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L170-L185) performs same type cast
	- [isExile[address(uniswapV2Pair)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L176) casts (address) to (address).
	- [marketPair[address(uniswapV2Pair)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L183) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L170-L185


 - [ ] ID-9
[POTUS.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L170-L185) performs same type cast
	- [isExile[address(uniswapV2Pair)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L176) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9408a514B4cb25f4689C6Fa2D4dc1895E8a97D7C/contract.sol#L170-L185


