**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (4 results) (Optimization)
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[CREATE.openTrading()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L315-L328) casts address(this) 3 time(s):-
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L321)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L322)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L323)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L315-L328


 - [ ] ID-1
[CREATE._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L210-L263) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L236)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L240)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L247)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L249)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L257)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L258)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L210-L263


 - [ ] ID-2
[CREATE.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L345-L355) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L347)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L351)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L345-L355


 - [ ] ID-3
[CREATE.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L270-L282) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L272)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L274)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L275-L281)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L270-L282


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-4
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L39-L46) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L44)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L39-L46


 - [ ] ID-5
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L52-L56) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L54)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L52-L56


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-6
[CREATE](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L110-L357) should use bytes32 for following string constant(s) :-
	- [CREATE._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L130)
	- [CREATE._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L131)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x8B325f92f9C246a681F37BBd97065B9097e0F324/contract.sol#L110-L357


