**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-0
[ProofOfContributionChainToken](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x912656188616e0184e3181f019022990a63280b1/contract.sol#L3-L65) should use bytes32 for following string constant(s) :-
	- [ProofOfContributionChainToken.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x912656188616e0184e3181f019022990a63280b1/contract.sol#L4)
	- [ProofOfContributionChainToken.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x912656188616e0184e3181f019022990a63280b1/contract.sol#L5)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x912656188616e0184e3181f019022990a63280b1/contract.sol#L3-L65


