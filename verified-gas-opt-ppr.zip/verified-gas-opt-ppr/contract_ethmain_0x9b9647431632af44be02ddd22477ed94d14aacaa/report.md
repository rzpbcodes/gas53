**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-0
[KOKContract](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9b9647431632af44be02ddd22477ed94d14aacaa/contract.sol#L36-L143) should use bytes32 for following string constant(s) :-
	- [KOKContract.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9b9647431632af44be02ddd22477ed94d14aacaa/contract.sol#L37)
	- [KOKContract.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9b9647431632af44be02ddd22477ed94d14aacaa/contract.sol#L38)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x9b9647431632af44be02ddd22477ed94d14aacaa/contract.sol#L36-L143


