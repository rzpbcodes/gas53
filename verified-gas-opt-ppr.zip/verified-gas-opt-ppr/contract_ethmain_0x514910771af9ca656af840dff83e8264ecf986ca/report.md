**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L15-L20) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L17)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L15-L20


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L9-L13) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(a == 0 || c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L11)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L9-L13


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-2
[LinkToken](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L220-L296) should use bytes32 for following string constant(s) :-
	- [LinkToken.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L223)
	- [LinkToken.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L225)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x514910771af9ca656af840dff83e8264ecf986ca/contract.sol#L220-L296


