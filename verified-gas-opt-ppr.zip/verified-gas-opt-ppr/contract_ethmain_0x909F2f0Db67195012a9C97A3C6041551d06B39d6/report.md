**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (4 results) (Optimization)
 - [div-by-uint](#div-by-uint) (3 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[DREAM.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L334-L344) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L336)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L340)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L334-L344


 - [ ] ID-1
[DREAM.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L272-L284) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L274)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L276)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L277-L283)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L272-L284


 - [ ] ID-2
[DREAM._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L223-L265) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L238)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L242)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L249)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L251)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L259)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L260)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L223-L265


 - [ ] ID-3
[DREAM.openTrading()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L313-L322) casts address(this) 3 time(s):-
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L316)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L317)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L318)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L313-L322


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-4
[DREAM.slitherConstructorConstantVariables()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L118-L346) perform division which can not overflow (can use unchecked) :-
	- [_vshare = _tTotal / 10](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L139)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L118-L346


 - [ ] ID-5
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L60-L64) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L62)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L60-L64


 - [ ] ID-6
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L47-L54) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L52)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L47-L54


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-7
[DREAM](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L118-L346) should use bytes32 for following string constant(s) :-
	- [DREAM._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L141)
	- [DREAM._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L142)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x909F2f0Db67195012a9C97A3C6041551d06B39d6/contract.sol#L118-L346


