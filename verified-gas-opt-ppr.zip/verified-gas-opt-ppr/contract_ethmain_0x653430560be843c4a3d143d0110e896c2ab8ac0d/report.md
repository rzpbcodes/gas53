**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (1 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x653430560be843c4a3d143d0110e896c2ab8ac0d/contract.sol#L32-L36) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(_a == 0 || c / _a == _b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x653430560be843c4a3d143d0110e896c2ab8ac0d/contract.sol#L34)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x653430560be843c4a3d143d0110e896c2ab8ac0d/contract.sol#L32-L36


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-1
[Token](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x653430560be843c4a3d143d0110e896c2ab8ac0d/contract.sol#L54-L115) should use bytes32 for following string constant(s) :-
	- [Token.standard](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x653430560be843c4a3d143d0110e896c2ab8ac0d/contract.sol#L55)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x653430560be843c4a3d143d0110e896c2ab8ac0d/contract.sol#L54-L115


