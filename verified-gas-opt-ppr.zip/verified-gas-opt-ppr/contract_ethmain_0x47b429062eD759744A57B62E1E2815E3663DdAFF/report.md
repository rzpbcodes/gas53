**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (5 results) (Optimization)
 - [div-by-uint](#div-by-uint) (3 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[IVANKA.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L162-L172) casts address(this) 3 time(s):-
	- [_balances[address(this)] = _tTotal.mul(80).div(100)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L164)
	- [_isExcludedFromFee[address(this)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L167)
	- [Transfer(address(0),address(this),_tTotal.mul(80).div(100))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L170)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L162-L172


 - [ ] ID-1
[IVANKA.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L335-L345) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L337)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L341)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L335-L345


 - [ ] ID-2
[IVANKA._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L221-L270) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L243)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L247)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L254)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L256)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L264)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L265)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L221-L270


 - [ ] ID-3
[IVANKA.openTrading()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L322-L331) casts address(this) 3 time(s):-
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L325)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L326)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L327)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L322-L331


 - [ ] ID-4
[IVANKA.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L277-L289) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L279)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L281)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L282-L288)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L277-L289


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-5
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L49-L56) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L54)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L49-L56


 - [ ] ID-6
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L62-L66) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L64)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L62-L66


 - [ ] ID-7
[IVANKA.slitherConstructorVariables()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L120-L353) perform division which can not overflow (can use unchecked) :-
	- [_maxTxAmount = 1 * (_tTotal / 100)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L142)
	- [_maxWalletSize = 1 * (_tTotal / 100)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L143)
	- [_taxSwapThreshold = 1 * (_tTotal / 1000)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L144)
	- [_maxTaxSwap = 1 * (_tTotal / 100)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L145)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L120-L353


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-8
[IVANKA](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L120-L353) should use bytes32 for following string constant(s) :-
	- [IVANKA._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L140)
	- [IVANKA._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L141)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x47b429062eD759744A57B62E1E2815E3663DdAFF/contract.sol#L120-L353


