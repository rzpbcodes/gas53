**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (5 results) (Optimization)
 - [div-by-uint](#div-by-uint) (8 results) (Optimization)
 - [unnec-casting-same-type](#unnec-casting-same-type) (5 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[FTP._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L879-L981) casts address(this) 2 time(s):-
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L929)
	- [super._transfer(from,address(this),fees)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L974)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L879-L981


 - [ ] ID-1
[FTP.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L747-L795) casts address(this) 3 time(s):-
	- [uniswapV2Pair = IUniswapV2Factory(_uniswapV2Router.factory()).createPair(address(this),_uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L754)
	- [excludeFromFees(address(this),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L787)
	- [excludeFromMaxTransaction(address(this),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L791)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L747-L795


 - [ ] ID-2
[FTP.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L983-L1001) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L987)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L990)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L993-L999)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L983-L1001


 - [ ] ID-3
[FTP.addLiquidity(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1004-L1017) casts address(this) 2 time(s):-
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1006)
	- [uniswapV2Router.addLiquidityETH{value: ethAmount}(address(this),tokenAmount,0,0,deadAddress,block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1009-L1016)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1004-L1017


 - [ ] ID-4
[FTP.swapBack()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1019-L1056) casts address(this) 4 time(s):-
	- [contractBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1020)
	- [initialETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1034)
	- [ethBalance = address(this).balance - initialETHBalance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1038)
	- [(success,None) = address(marketingWallet).call{value: address(this).balance}()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1055)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1019-L1056


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-5
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L462-L474) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L471)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L462-L474


 - [ ] ID-6
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L504-L510) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L506)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L504-L510


 - [ ] ID-7
[FTP.updateSwapTokensAtAmount(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L816-L820) perform division which can not overflow (can use unchecked) :-
	- [swapTokensAtAmount = totalSupply() * newAmount / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L818)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L816-L820


 - [ ] ID-8
[FTP.updateMaxTxnAmount(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L822-L827) perform division which can not overflow (can use unchecked) :-
	- [maxTransactionAmount = (totalSupply() * txNum / 100) / 1e18](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L824)
	- [maxWallet = (totalSupply() * walNum / 100) / 1e18](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L826)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L822-L827


 - [ ] ID-9
[FTP._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L879-L981) perform division which can not overflow (can use unchecked) :-
	- [fees = amount * sellTotalFees / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L960)
	- [tokensForLiquidity += fees * sellLiquidityFee / sellTotalFees](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L961)
	- [tokensForDev += fees * sellDevFee / sellTotalFees](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L962)
	- [tokensForMarketing += fees * sellMarketingFee / sellTotalFees](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L963)
	- [fees = amount * buyTotalFees / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L967)
	- [tokensForLiquidity += fees * buyLiquidityFee / buyTotalFees](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L968)
	- [tokensForDev += fees * buyDevFee / buyTotalFees](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L969)
	- [tokensForMarketing += fees * buyMarketingFee / buyTotalFees](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L970)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L879-L981


 - [ ] ID-10
[FTP.swapBack()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1019-L1056) perform division which can not overflow (can use unchecked) :-
	- [liquidityTokens = contractBalance * tokensForLiquidity / totalTokensToSwap / 2](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1031)
	- [ethForMarketing = ethBalance * tokensForMarketing / totalTokensToSwap](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1040)
	- [ethForDev = ethBalance * tokensForDev / totalTokensToSwap](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1041)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1019-L1056


 - [ ] ID-11
[FTP.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L747-L795) perform division which can not overflow (can use unchecked) :-
	- [maxTransactionAmount = totalSupply * 2 / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L768)
	- [maxWallet = totalSupply * 2 / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L769)
	- [swapTokensAtAmount = totalSupply * 2 / 1000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L770)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L747-L795


 - [ ] ID-12
[FTP.manualBurnLiquidityPairTokens(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1058-L1078) perform division which can not overflow (can use unchecked) :-
	- [amountToBurn = liquidityPairBalance * percent / 10000](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1067)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1058-L1078


## unnec-casting-same-type
Impact: Optimization
Confidence: High
 - [ ] ID-13
[FTP._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L879-L981) performs same type cast
	- [to != owner() && to != address(uniswapV2Router) && to != address(uniswapV2Pair)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L907) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L879-L981


 - [ ] ID-14
[FTP.swapBack()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1019-L1056) performs same type cast
	- [(success,None) = address(devWallet).call{value: ethForDev}()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1049) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1019-L1056


 - [ ] ID-15
[FTP.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L747-L795) performs same type cast
	- [excludeFromMaxTransaction(address(uniswapV2Pair),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L755) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L747-L795


 - [ ] ID-16
[FTP.swapBack()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1019-L1056) performs same type cast
	- [(success,None) = address(devWallet).call{value: ethForDev}()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1049) casts (address) to (address).
	- [(success,None) = address(marketingWallet).call{value: address(this).balance}()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1055) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L1019-L1056


 - [ ] ID-17
[FTP.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L747-L795) performs same type cast
	- [excludeFromMaxTransaction(address(uniswapV2Pair),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L755) casts (address) to (address).
	- [_setAutomatedMarketMakerPair(address(uniswapV2Pair),true)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L756) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x983F9B055594aeE343Ecd5bCA2289F47E2A9c44E/contract.sol#L747-L795


