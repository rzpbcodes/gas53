**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L4-L8) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(a == 0 || c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L6)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L4-L8


 - [ ] ID-1
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L10-L13) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L11)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L10-L13


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-2
[SiaCashCoin](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L52-L228) should use bytes32 for following string constant(s) :-
	- [SiaCashCoin.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L63)
	- [SiaCashCoin.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L64)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x74fd51a98a4a1ecbef8cc43be801cce630e260bd/contract.sol#L52-L228


