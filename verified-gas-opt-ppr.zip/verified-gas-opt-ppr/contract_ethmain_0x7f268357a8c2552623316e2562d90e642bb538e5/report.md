**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (3 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L8-L15) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L13)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L8-L15


 - [ ] ID-1
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L20-L25) perform division which can not overflow (can use unchecked) :-
	- [a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L24)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L20-L25


 - [ ] ID-2
[ArrayUtils.guardedArrayReplace(bytes,bytes,bytes)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L125-L162) perform division which can not overflow (can use unchecked) :-
	- [words = array.length / 0x20](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L132)
	- [assert(bool)(index / 0x20 == words)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L134)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L125-L162


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-3
[WyvernExchangeWithBulkCancellations](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L1507-L1522) should use bytes32 for following string constant(s) :-
	- [ExchangeCore.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L366)
	- [ExchangeCore.version](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L367)
	- [WyvernExchangeWithBulkCancellations.codename](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L1508)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7f268357a8c2552623316e2562d90e642bb538e5/contract.sol#L1507-L1522


