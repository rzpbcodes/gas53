**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (1 results) (Optimization)
 - [div-by-uint](#div-by-uint) (21 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[TransformableToken.xfLobbyFlush()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2794-L2800) casts address(this) 2 time(s):-
	- [require(bool,string)(address(this).balance != 0,HEX: No value)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2797)
	- [FLUSH_ADDR.transfer(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2799)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2794-L2800


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-1
[TransformableToken._waasLobby(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2877-L2896) perform division which can not overflow (can use unchecked) :-
	- [waasLobby = unclaimed * HEARTS_PER_SATOSHI / CLAIM_PHASE_DAYS](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2889)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2877-L2896


 - [ ] ID-2
[StakeableToken._stakeStartBonusHearts(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1601-L1670) perform division which can not overflow (can use unchecked) :-
	- [bonusHearts = newStakedHearts * bonusHearts / (LPB * BPB)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1667)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1601-L1670


 - [ ] ID-3
[UTXORedeemableToken._satoshisClaim(GlobalsAndUtility.GlobalsCache,uint256,address,bytes20,uint8,uint256,address)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2409-L2461) perform division which can not overflow (can use unchecked) :-
	- [autoStakeHearts = totalClaimedHearts * AUTO_STAKE_CLAIM_PERCENT / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2454)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2409-L2461


 - [ ] ID-4
[StakeableToken._calcPayoutAndEarlyPenalty(GlobalsAndUtility.GlobalsCache,uint256,uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1720-L1775) perform division which can not overflow (can use unchecked) :-
	- [penaltyDays = (stakedDaysParam + 1) / 2](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1734)
	- [penalty = payout * penaltyDays / servedDays](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1772)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1720-L1775


 - [ ] ID-5
[StakeableToken._stakeStart(GlobalsAndUtility.GlobalsCache,uint256,uint256,bool)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1515-L1561) perform division which can not overflow (can use unchecked) :-
	- [newStakeShares = (newStakedHearts + bonusHearts) * SHARE_RATE_SCALE / g._shareRate](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1527)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1515-L1561


 - [ ] ID-6
[StakeableToken._calcPayoutRewards(GlobalsAndUtility.GlobalsCache,uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1571-L1594) perform division which can not overflow (can use unchecked) :-
	- [payout += dailyData[day].dayPayoutTotal * stakeSharesParam / dailyData[day].dayStakeSharesTotal](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1582-L1583)
	- [bigPaySlice = g._unclaimedSatoshisTotal * HEARTS_PER_SATOSHI * stakeSharesParam / dailyData[BIG_PAY_DAY].dayStakeSharesTotal](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1588-L1589)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1571-L1594


 - [ ] ID-7
[StakeableToken._calcLatePenalty(uint256,uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1777-L1795) perform division which can not overflow (can use unchecked) :-
	- [rawStakeReturn * (unlockedDayParam - maxUnlockedDay) / LATE_PENALTY_SCALE_DAYS](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1794)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1777-L1795


 - [ ] ID-8
[TransformableToken.xfLobbyExit(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2723-L2789) perform division which can not overflow (can use unchecked) :-
	- [xfAmount = waasLobby * rawAmount / _xfLobby](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2752)
	- [referralBonusHearts = xfAmount / 10](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2759)
	- [referrerBonusHearts = xfAmount / 5](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2764)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2723-L2789


 - [ ] ID-9
[StakeableToken._shareRateUpdate(GlobalsAndUtility.GlobalsCache,GlobalsAndUtility.StakeCache,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1812-L1839) perform division which can not overflow (can use unchecked) :-
	- [newShareRate = (stakeReturn + bonusHearts) * SHARE_RATE_SCALE / st._stakeShares](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1822)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1812-L1839


 - [ ] ID-10
[GlobalsAndUtility._dailyRoundCalc(GlobalsAndUtility.GlobalsCache,GlobalsAndUtility.DailyRoundState,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1222-L1257) perform division which can not overflow (can use unchecked) :-
	- [rs._payoutTotal = rs._allocSupplyCached * 10000 / 100448995](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1241)
	- [bigPaySlice = g._unclaimedSatoshisTotal * HEARTS_PER_SATOSHI / CLAIM_PHASE_DAYS](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1244)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1222-L1257


 - [ ] ID-11
[GlobalsAndUtility._estimatePayoutRewardsDay(GlobalsAndUtility.GlobalsCache,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1172-L1198) perform division which can not overflow (can use unchecked) :-
	- [payout = rs._payoutTotal * stakeSharesParam / gTmp._stakeSharesTotal](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1189)
	- [bigPaySlice = gTmp._unclaimedSatoshisTotal * HEARTS_PER_SATOSHI * stakeSharesParam / gTmp._stakeSharesTotal](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1192-L1193)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1172-L1198


 - [ ] ID-12
[UTXORedeemableToken._adjustLateClaim(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2654-L2666) perform division which can not overflow (can use unchecked) :-
	- [adjSatoshis * daysRemaining / CLAIM_PHASE_DAYS](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2665)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2654-L2666


 - [ ] ID-13
[StakeableToken._splitPenaltyProceeds(GlobalsAndUtility.GlobalsCache,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1797-L1810) perform division which can not overflow (can use unchecked) :-
	- [splitPenalty = penalty / 2](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1801)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1797-L1810


 - [ ] ID-14
[GlobalsAndUtility._currentDay()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L974-L980) perform division which can not overflow (can use unchecked) :-
	- [(block.timestamp - LAUNCH_TIME) / 86400](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L979)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L974-L980


 - [ ] ID-15
[GlobalsAndUtility._calcAdoptionBonus(GlobalsAndUtility.GlobalsCache,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1200-L1220) perform division which can not overflow (can use unchecked) :-
	- [viral = payout * g._claimedBtcAddrCount / CLAIMABLE_BTC_ADDR_COUNT](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1210)
	- [crit = payout * g._claimedSatoshisTotal / CLAIMABLE_SATOSHIS_TOTAL](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1217)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L1200-L1220


 - [ ] ID-16
[HEX.slitherConstructorConstantVariables()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2933-L2953) perform division which can not overflow (can use unchecked) :-
	- [HEARTS_PER_SATOSHI = HEARTS_PER_HEX / SATOSHIS_PER_BTC * HEX_PER_BTC](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L647)
	- [LPB = 364 * 100 / LPB_BONUS_PERCENT](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L727)
	- [LPB_MAX_DAYS = LPB * LPB_BONUS_MAX_PERCENT / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L728)
	- [BPB = BPB_MAX_HEARTS * 100 / BPB_BONUS_PERCENT](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L734)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2933-L2953


 - [ ] ID-17
[UTXORedeemableToken._calcSpeedBonus(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2674-L2689) perform division which can not overflow (can use unchecked) :-
	- [claimedHearts * (daysRemaining - 1) / ((CLAIM_PHASE_DAYS - 1) * 5)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2688)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2674-L2689


 - [ ] ID-18
[UTXORedeemableToken._adjustSillyWhale(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2605-L2646) perform division which can not overflow (can use unchecked) :-
	- [rawSatoshis / 4](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2616)
	- [rawSatoshis * (19000e8 - rawSatoshis) / 36000e8](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2645)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2605-L2646


 - [ ] ID-19
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L216-L223) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L219)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L216-L223


 - [ ] ID-20
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L174-L186) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L183)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L174-L186


 - [ ] ID-21
[UTXORedeemableToken._remitBonuses(address,bytes20,uint8,uint256,uint256,uint256,uint256,address)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2463-L2532) perform division which can not overflow (can use unchecked) :-
	- [referralBonusHearts = totalClaimedHearts / 10](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2493)
	- [referrerBonusHearts = totalClaimedHearts / 5](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2498)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2463-L2532


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-22
[HEX](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2933-L2953) should use bytes32 for following string constant(s) :-
	- [GlobalsAndUtility.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L639)
	- [GlobalsAndUtility.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L640)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x2b591e99afe9f32eaa6214f7b7629768c40eeb39/contract.sol#L2933-L2953


