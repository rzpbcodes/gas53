**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (2 results) (Optimization)
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Dice2Win.increaseJackpot(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L172-L176) casts address(this) 2 time(s):-
	- [require(bool,string)(increaseAmount <= address(this).balance,Increase amount larger than balance.)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L173)
	- [require(bool,string)(jackpotSize + lockedInBets + increaseAmount <= address(this).balance,Not enough funds.)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L174)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L172-L176


 - [ ] ID-1
[Dice2Win.withdrawFunds(address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L179-L183) casts address(this) 2 time(s):-
	- [require(bool,string)(withdrawAmount <= address(this).balance,Increase amount larger than balance.)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L180)
	- [require(bool,string)(jackpotSize + lockedInBets + withdrawAmount <= address(this).balance,Not enough funds.)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L181)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L179-L183


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-2
[Dice2Win.getDiceWinAmount(uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L429-L442) perform division which can not overflow (can use unchecked) :-
	- [houseEdge = amount * HOUSE_EDGE_PERCENT / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L434)
	- [winAmount = (amount - houseEdge - jackpotFee) * modulo / rollUnder](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L441)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L429-L442


 - [ ] ID-3
[Dice2Win.settleBetCommon(Dice2Win.Bet,uint256,bytes32)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L330-L397) perform division which can not overflow (can use unchecked) :-
	- [jackpotRng = (uint256(entropy) / modulo) % JACKPOT_MODULO](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L381)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd1ceeeeee83f8bcf3bedad437202b6154e9f5405/contract.sol#L330-L397


