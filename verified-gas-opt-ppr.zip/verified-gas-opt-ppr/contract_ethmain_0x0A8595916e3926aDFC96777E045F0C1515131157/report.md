**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (5 results) (Optimization)
 - [div-by-uint](#div-by-uint) (1 results) (Optimization)
 - [unnec-casting-same-type](#unnec-casting-same-type) (2 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[DBA.openTrading(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L434-L450) casts address(this) 3 time(s):-
	- [super._transfer(msg.sender,address(this),super.balanceOf(msg.sender))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L435)
	- [uniRouter.addLiquidityETH{value: token0}(address(this),token1,0,0,msg.sender,block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L437-L444)
	- [uniPair = IUniswapV2Factory(uniRouter.factory()).getPair(address(this),uniRouter.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L446-L449)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L434-L450


 - [ ] ID-1
[DBA._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L347-L410) casts address(this) 3 time(s):-
	- [contractTokenBalance = this.balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L381)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L394)
	- [super._transfer(from,address(this),fees)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L405)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L347-L410


 - [ ] ID-2
[DBA.sweepStuckTokens(IERC20)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L477-L482) casts address(this) 3 time(s):-
	- [address(token) == address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L479)
	- [token.transfer(address(0xdead),token.balanceOf(address(this)))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L480)
	- [token.transfer(feeReceiver,token.balanceOf(address(this)))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L481)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L477-L482


 - [ ] ID-3
[DBA.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L416-L428) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L418)
	- [_approve(address(this),address(uniRouter),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L420)
	- [uniRouter.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L421-L427)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L416-L428


 - [ ] ID-4
[DBA.constructor()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L329-L345) casts address(this) 2 time(s):-
	- [_excludedFromLimits[address(this)] = true](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L339)
	- [_approve(address(this),address(uniRouter),totalSupply)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L342)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L329-L345


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-5
[DBA._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L347-L410) perform division which can not overflow (can use unchecked) :-
	- [fees = (amount * fee) / 100](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L403)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L347-L410


## unnec-casting-same-type
Impact: Optimization
Confidence: High
 - [ ] ID-6
[DBA.sendETHToFee(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L430-L432) performs same type cast
	- [address(feeReceiver).transfer(amount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L431) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L430-L432


 - [ ] ID-7
[DBA.transferStuckETH()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L473-L475) performs same type cast
	- [address(feeReceiver).transfer(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L474) casts (address) to (address).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0A8595916e3926aDFC96777E045F0C1515131157/contract.sol#L473-L475


