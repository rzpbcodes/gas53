**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd7cc16500d0b0ac3d0ba156a584865a43b0b0050/contract.sol#L58-L70) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd7cc16500d0b0ac3d0ba156a584865a43b0b0050/contract.sol#L67)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd7cc16500d0b0ac3d0ba156a584865a43b0b0050/contract.sol#L58-L70


 - [ ] ID-1
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd7cc16500d0b0ac3d0ba156a584865a43b0b0050/contract.sol#L83-L90) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd7cc16500d0b0ac3d0ba156a584865a43b0b0050/contract.sol#L86)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xd7cc16500d0b0ac3d0ba156a584865a43b0b0050/contract.sol#L83-L90


