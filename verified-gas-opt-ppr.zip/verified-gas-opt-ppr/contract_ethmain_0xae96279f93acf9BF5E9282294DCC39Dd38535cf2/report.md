**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (4 results) (Optimization)
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[TMP47.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L338-L348) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L340)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L344)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L338-L348


 - [ ] ID-1
[TMP47.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L272-L284) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L274)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L276)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L277-L283)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L272-L284


 - [ ] ID-2
[TMP47._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L216-L265) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L238)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L242)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L249)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L251)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L259)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L260)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L216-L265


 - [ ] ID-3
[TMP47.openTrading()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L317-L326) casts address(this) 3 time(s):-
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L320)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L321)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L322)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L317-L326


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-4
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L59-L63) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L61)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L59-L63


 - [ ] ID-5
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L46-L53) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L51)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L46-L53


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-6
[TMP47](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L117-L350) should use bytes32 for following string constant(s) :-
	- [TMP47._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L137)
	- [TMP47._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L138)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xae96279f93acf9BF5E9282294DCC39Dd38535cf2/contract.sol#L117-L350


