**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xac08809df1048b82959d6251fbc9538920bed1fa/contract.sol#L4-L11) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xac08809df1048b82959d6251fbc9538920bed1fa/contract.sol#L9)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xac08809df1048b82959d6251fbc9538920bed1fa/contract.sol#L4-L11


 - [ ] ID-1
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xac08809df1048b82959d6251fbc9538920bed1fa/contract.sol#L13-L16) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xac08809df1048b82959d6251fbc9538920bed1fa/contract.sol#L14)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xac08809df1048b82959d6251fbc9538920bed1fa/contract.sol#L13-L16


