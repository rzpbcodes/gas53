**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (4 results) (Optimization)
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Contract.manualSwap()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L297-L307) casts address(this) 2 time(s):-
	- [tokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L299)
	- [ethBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L303)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L297-L307


 - [ ] ID-1
[Contract.openTrading()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L285-L294) casts address(this) 3 time(s):-
	- [_approve(address(this),address(uniswapV2Router),_tTotal)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L288)
	- [uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this),uniswapV2Router.WETH())](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L289)
	- [uniswapV2Router.addLiquidityETH{value: address(this).balance}(address(this),balanceOf(address(this)),0,0,owner(),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L290)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L285-L294


 - [ ] ID-2
[Contract.swapTokensForEth(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L257-L269) casts address(this) 3 time(s):-
	- [path[0] = address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L259)
	- [_approve(address(this),address(uniswapV2Router),tokenAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L261)
	- [uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(tokenAmount,0,path,address(this),block.timestamp)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L262-L268)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L257-L269


 - [ ] ID-3
[Contract._transfer(address,address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L208-L250) casts address(this) 6 time(s):-
	- [to == uniswapV2Pair && from != address(this)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L223)
	- [contractTokenBalance = balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L227)
	- [contractETHBalance = address(this).balance](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L234)
	- [sendETHToFee(address(this).balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L236)
	- [_balances[address(this)] = _balances[address(this)].add(taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L244)
	- [Transfer(from,address(this),taxAmount)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L245)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L208-L250


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-4
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L53-L57) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L55)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L53-L57


 - [ ] ID-5
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L40-L47) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L45)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L40-L47


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-6
[Contract](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L111-L309) should use bytes32 for following string constant(s) :-
	- [Contract._name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L130)
	- [Contract._symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L131)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xD257BD72171eecAdFDDbfcbb923FA2EC0739CCA8/contract.sol#L111-L309


