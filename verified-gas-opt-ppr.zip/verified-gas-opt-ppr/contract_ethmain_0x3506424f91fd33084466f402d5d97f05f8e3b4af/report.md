**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x3506424f91fd33084466f402d5d97f05f8e3b4af/contract.sol#L66-L72) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x3506424f91fd33084466f402d5d97f05f8e3b4af/contract.sol#L68)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x3506424f91fd33084466f402d5d97f05f8e3b4af/contract.sol#L66-L72


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x3506424f91fd33084466f402d5d97f05f8e3b4af/contract.sol#L49-L61) perform division which can not overflow (can use unchecked) :-
	- [require(bool)(c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x3506424f91fd33084466f402d5d97f05f8e3b4af/contract.sol#L58)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x3506424f91fd33084466f402d5d97f05f8e3b4af/contract.sol#L49-L61


