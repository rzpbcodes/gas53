**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L94-L98) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(a == 0 || c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L96)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L94-L98


 - [ ] ID-1
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L100-L105) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L102)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L100-L105


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-2
[MANAToken](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L267-L279) should use bytes32 for following string constant(s) :-
	- [MANAToken.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L269)
	- [MANAToken.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L271)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x0f5d2fb29fb7d3cfee444a200298f468908cc942/contract.sol#L267-L279


