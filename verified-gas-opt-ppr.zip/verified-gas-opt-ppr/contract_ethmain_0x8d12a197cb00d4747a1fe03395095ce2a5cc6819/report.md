**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (4 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[EtherDelta.trade(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32,uint256)]() perform division which can not overflow (can use unchecked) :-
	- [Trade(tokenGet,amount,tokenGive,amountGive * amount / amountGet,user,msg.sender)]()

 - [ ] ID-1
[EtherDelta.tradeBalances(address,uint256,address,uint256,address,uint256)]() perform division which can not overflow (can use unchecked) :-
	- [feeMakeXfer = safeMul(amount,feeMake) / (1000000000000000000)]()
	- [feeTakeXfer = safeMul(amount,feeTake) / (1000000000000000000)]()
	- [feeRebateXfer = safeMul(amount,feeRebate) / (1000000000000000000)]()
	- [tokens[tokenGive][user] = safeSub(tokens[tokenGive][user],safeMul(amountGive,amount) / amountGet)]()
	- [tokens[tokenGive][msg.sender] = safeAdd(tokens[tokenGive][msg.sender],safeMul(amountGive,amount) / amountGet)]()

 - [ ] ID-2
[SafeMath.safeMul(uint256,uint256)]() perform division which can not overflow (can use unchecked) :-
	- [assert(a == 0 || c / a == b)]()

 - [ ] ID-3
[EtherDelta.availableVolume(address,uint256,address,uint256,uint256,uint256,address,uint8,bytes32,bytes32)]() perform division which can not overflow (can use unchecked) :-
	- [available2 = safeMul(tokens[tokenGive][user],amountGet) / amountGive]()

