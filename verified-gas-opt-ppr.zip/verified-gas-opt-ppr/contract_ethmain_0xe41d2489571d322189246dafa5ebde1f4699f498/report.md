**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-0
[ZRXToken](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xe41d2489571d322189246dafa5ebde1f4699f498/contract.sol#L130-L141) should use bytes32 for following string constant(s) :-
	- [ZRXToken.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xe41d2489571d322189246dafa5ebde1f4699f498/contract.sol#L134)
	- [ZRXToken.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xe41d2489571d322189246dafa5ebde1f4699f498/contract.sol#L135)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xe41d2489571d322189246dafa5ebde1f4699f498/contract.sol#L130-L141


