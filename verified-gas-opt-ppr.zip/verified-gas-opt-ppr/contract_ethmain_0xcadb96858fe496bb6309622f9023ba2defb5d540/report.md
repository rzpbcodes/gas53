**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (3 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.ceilDiv(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L54-L56) perform division which can not overflow (can use unchecked) :-
	- [(_x + _y - 1) / _y](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L55)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L54-L56


 - [ ] ID-1
[SafeMath.safeDiv(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L47-L52) perform division which can not overflow (can use unchecked) :-
	- [_x / _y](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L51)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L47-L52


 - [ ] ID-2
[SafeMath.safeMul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L41-L45) perform division which can not overflow (can use unchecked) :-
	- [require(bool)(_x == 0 || z / _x == _y)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L43)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xcadb96858fe496bb6309622f9023ba2defb5d540/contract.sol#L41-L45


