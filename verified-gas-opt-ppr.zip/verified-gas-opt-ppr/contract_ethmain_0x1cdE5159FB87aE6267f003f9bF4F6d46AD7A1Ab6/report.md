**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [cache-address-this](#cache-address-this) (2 results) (Optimization)
 - [div-by-uint](#div-by-uint) (4 results) (Optimization)
## cache-address-this
Impact: Optimization
Confidence: High
 - [ ] ID-0
[AxiomNet.oracle()](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L395-L403) casts address(this) 3 time(s):-
	- [require(bool,string)(_balances[address(this)] >= mintQuantity,Insufficient balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L399)
	- [_balances[address(this)] = _balances[address(this)].sub(mintQuantity)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L401)
	- [Transfer(address(this),msg.sender,mintQuantity)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L402)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L395-L403


 - [ ] ID-1
[AxiomNet.claimStuckTokens(address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L425-L438) casts address(this) 3 time(s):-
	- [require(bool,string)(token != address(this),Owner cannot claim contract's balance of its own tokens)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L426)
	- [require(bool,string)(amount <= address(this).balance,Insufficient contract balance)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L429)
	- [contractBalance = ERC20token.balanceOf(address(this))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L435)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L425-L438


## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-2
[SafeMath.tryMul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L20-L27) perform division which can not overflow (can use unchecked) :-
	- [c / a != b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L24)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L20-L27


 - [ ] ID-3
[SafeMath.div(uint256,uint256,string)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L74-L83) perform division which can not overflow (can use unchecked) :-
	- [a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L81)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L74-L83


 - [ ] ID-4
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L55-L57) perform division which can not overflow (can use unchecked) :-
	- [a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L56)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L55-L57


 - [ ] ID-5
[SafeMath.tryDiv(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L29-L34) perform division which can not overflow (can use unchecked) :-
	- [(true,a / b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L32)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x1cdE5159FB87aE6267f003f9bF4F6d46AD7A1Ab6/contract.sol#L29-L34


