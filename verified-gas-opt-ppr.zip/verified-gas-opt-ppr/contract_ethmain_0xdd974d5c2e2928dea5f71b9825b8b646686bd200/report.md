**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L10-L15) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L12)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L10-L15


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L4-L8) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(a == 0 || c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L6)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L4-L8


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-2
[KyberNetworkCrystal](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L169-L241) should use bytes32 for following string constant(s) :-
	- [KyberNetworkCrystal.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L170)
	- [KyberNetworkCrystal.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L171)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xdd974d5c2e2928dea5f71b9825b8b646686bd200/contract.sol#L169-L241


