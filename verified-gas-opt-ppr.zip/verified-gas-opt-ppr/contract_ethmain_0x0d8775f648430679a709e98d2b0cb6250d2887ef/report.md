**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.safeMult(uint256,uint256)]() perform division which can not overflow (can use unchecked) :-
	- [assert(bool)((x == 0) || (z / x == y))]()

 - [ ] ID-1
[BAToken.refund()]() perform division which can not overflow (can use unchecked) :-
	- [ethVal = batVal / tokenExchangeRate]()

