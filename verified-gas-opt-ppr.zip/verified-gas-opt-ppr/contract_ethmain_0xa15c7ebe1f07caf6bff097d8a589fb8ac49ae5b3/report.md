**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L15-L20) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L17)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L15-L20


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L9-L13) perform division which can not overflow (can use unchecked) :-
	- [assert(bool)(a == 0 || c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L11)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L9-L13


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-2
[NPXSToken](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L577-L646) should use bytes32 for following string constant(s) :-
	- [NPXSToken.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L579)
	- [NPXSToken.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L580)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xa15c7ebe1f07caf6bff097d8a589fb8ac49ae5b3/contract.sol#L577-L646


