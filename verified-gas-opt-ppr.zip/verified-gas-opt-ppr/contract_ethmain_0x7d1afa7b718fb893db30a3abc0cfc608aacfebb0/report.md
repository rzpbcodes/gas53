**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7d1afa7b718fb893db30a3abc0cfc608aacfebb0/contract.sol#L54-L61) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7d1afa7b718fb893db30a3abc0cfc608aacfebb0/contract.sol#L57)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7d1afa7b718fb893db30a3abc0cfc608aacfebb0/contract.sol#L54-L61


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7d1afa7b718fb893db30a3abc0cfc608aacfebb0/contract.sol#L37-L49) perform division which can not overflow (can use unchecked) :-
	- [require(bool)(c / a == b)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7d1afa7b718fb893db30a3abc0cfc608aacfebb0/contract.sol#L46)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x7d1afa7b718fb893db30a3abc0cfc608aacfebb0/contract.sol#L37-L49


