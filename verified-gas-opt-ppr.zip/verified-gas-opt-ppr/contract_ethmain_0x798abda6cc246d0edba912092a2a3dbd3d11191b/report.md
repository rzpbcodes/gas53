**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (6 results) (Optimization)
 - [unnec-casting-same-type](#unnec-casting-same-type) (5 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Utils.calcSrcQty(uint256,uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L417-L434) perform division which can not overflow (can use unchecked) :-
	- [(numerator + denominator - 1) / denominator](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L433)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L417-L434


 - [ ] ID-1
[VolumeImbalanceRecorder.decodeTokenImbalanceData(uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L366-L375) perform division which can not overflow (can use unchecked) :-
	- [data.lastBlock = uint256(uint64((input / POW_2_64) & (POW_2_64 - 1)))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L370)
	- [data.totalBuyUnitsImbalance = int256(int64((input / (POW_2_64 * POW_2_64)) & (POW_2_64 - 1)))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L371)
	- [data.lastRateUpdateBlock = uint256(uint64((input / (POW_2_64 * POW_2_64 * POW_2_64))))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L372)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L366-L375


 - [ ] ID-2
[ConversionRates.addBps(uint256,int256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L787-L794) perform division which can not overflow (can use unchecked) :-
	- [(rate * uint256(int256(maxBps) + bps)) / maxBps](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L793)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L787-L794


 - [ ] ID-3
[VolumeImbalanceRecorder.encodeTokenImbalanceData(VolumeImbalanceRecorder.TokenImbalanceData)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L348-L364) perform division which can not overflow (can use unchecked) :-
	- [require(bool)(data.lastBlockBuyUnitsImbalance < int256(POW_2_64 / 2))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L350)
	- [require(bool)(data.lastBlockBuyUnitsImbalance > int256(- 1 * int256(POW_2_64) / 2))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L351)
	- [require(bool)(data.totalBuyUnitsImbalance < int256(POW_2_64 / 2))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L353)
	- [require(bool)(data.totalBuyUnitsImbalance > int256(- 1 * int256(POW_2_64) / 2))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L354)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L348-L364


 - [ ] ID-4
[ConversionRates.getLast4Bytes(bytes32)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L762-L765) perform division which can not overflow (can use unchecked) :-
	- [uint256(b) / (BYTES_14_OFFSET * BYTES_14_OFFSET)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L764)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L762-L765


 - [ ] ID-5
[Utils.calcDstQty(uint256,uint256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L404-L415) perform division which can not overflow (can use unchecked) :-
	- [(srcQty * rate * (10 ** (dstDecimals - srcDecimals))) / PRECISION](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L410)
	- [(srcQty * rate) / (PRECISION * (10 ** (srcDecimals - dstDecimals)))](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L413)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L404-L415


## unnec-casting-same-type
Impact: Optimization
Confidence: High
 - [ ] ID-6
[VolumeImbalanceRecorder.addImbalance(ERC20,int256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267) performs same type cast
	- [currentBlockData.totalBuyUnitsImbalance = int256(prevImbalance) + recordedBuyAmount](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L251) casts (int256) to (int256).
	- [currentBlockData.lastRateUpdateBlock = uint256(rateUpdateBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L253) casts (uint256) to (uint256).
	- [currentBlockData.lastBlock = uint256(currentBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L261) casts (uint256) to (uint256).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267


 - [ ] ID-7
[VolumeImbalanceRecorder.addImbalance(ERC20,int256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267) performs same type cast
	- [currentBlockData.totalBuyUnitsImbalance = int256(prevImbalance) + recordedBuyAmount](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L251) casts (int256) to (int256).
	- [currentBlockData.lastRateUpdateBlock = uint256(rateUpdateBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L253) casts (uint256) to (uint256).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267


 - [ ] ID-8
[VolumeImbalanceRecorder.addImbalance(ERC20,int256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267) performs same type cast
	- [currentBlockData.totalBuyUnitsImbalance = int256(prevImbalance) + recordedBuyAmount](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L251) casts (int256) to (int256).
	- [currentBlockData.lastRateUpdateBlock = uint256(rateUpdateBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L253) casts (uint256) to (uint256).
	- [currentBlockData.lastBlock = uint256(currentBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L261) casts (uint256) to (uint256).
	- [currentBlockData.lastRateUpdateBlock = uint256(rateUpdateBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L262) casts (uint256) to (uint256).
	- [currentBlockData.totalBuyUnitsImbalance = int256(prevImbalance) + recordedBuyAmount](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L263) casts (int256) to (int256).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267


 - [ ] ID-9
[VolumeImbalanceRecorder.addImbalance(ERC20,int256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267) performs same type cast
	- [currentBlockData.totalBuyUnitsImbalance = int256(prevImbalance) + recordedBuyAmount](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L251) casts (int256) to (int256).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267


 - [ ] ID-10
[VolumeImbalanceRecorder.addImbalance(ERC20,int256,uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267) performs same type cast
	- [currentBlockData.totalBuyUnitsImbalance = int256(prevImbalance) + recordedBuyAmount](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L251) casts (int256) to (int256).
	- [currentBlockData.lastRateUpdateBlock = uint256(rateUpdateBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L253) casts (uint256) to (uint256).
	- [currentBlockData.lastBlock = uint256(currentBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L261) casts (uint256) to (uint256).
	- [currentBlockData.lastRateUpdateBlock = uint256(rateUpdateBlock)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L262) casts (uint256) to (uint256).

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x798abda6cc246d0edba912092a2a3dbd3d11191b/contract.sol#L226-L267


