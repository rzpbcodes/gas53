**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (2 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[SafeMath.div(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce/contract.sol#L168-L175) perform division which can not overflow (can use unchecked) :-
	- [c = a / b](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce/contract.sol#L171)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce/contract.sol#L168-L175


 - [ ] ID-1
[SafeMath.mul(uint256,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce/contract.sol#L143-L155) perform division which can not overflow (can use unchecked) :-
	- [require(bool,string)(c / a == b,SafeMath: multiplication overflow)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce/contract.sol#L152)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce/contract.sol#L143-L155


