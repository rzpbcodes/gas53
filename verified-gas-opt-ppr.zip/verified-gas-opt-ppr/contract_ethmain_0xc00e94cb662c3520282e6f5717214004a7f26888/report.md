**THIS CHECKLIST IS NOT COMPLETE**. Use `--show-ignored-findings` to show all the results.
Summary
 - [div-by-uint](#div-by-uint) (1 results) (Optimization)
 - [smaller-string](#smaller-string) (1 results) (Optimization)
## div-by-uint
Impact: Optimization
Confidence: High
 - [ ] ID-0
[Comp.getPriorVotes(address,uint256)](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc00e94cb662c3520282e6f5717214004a7f26888/contract.sol#L189-L221) perform division which can not overflow (can use unchecked) :-
	- [center = upper - (upper - lower) / 2](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc00e94cb662c3520282e6f5717214004a7f26888/contract.sol#L210)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc00e94cb662c3520282e6f5717214004a7f26888/contract.sol#L189-L221


## smaller-string
Impact: Optimization
Confidence: High
 - [ ] ID-1
[Comp](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc00e94cb662c3520282e6f5717214004a7f26888/contract.sol#L4-L301) should use bytes32 for following string constant(s) :-
	- [Comp.name](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc00e94cb662c3520282e6f5717214004a7f26888/contract.sol#L6)
	- [Comp.symbol](../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc00e94cb662c3520282e6f5717214004a7f26888/contract.sol#L9)

../../contracts/verified-gas-opt-ppr/contract_ethmain_0xc00e94cb662c3520282e6f5717214004a7f26888/contract.sol#L4-L301


